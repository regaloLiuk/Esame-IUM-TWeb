package com.example.progetto;

public class SpinnerAdapterProf {
}
